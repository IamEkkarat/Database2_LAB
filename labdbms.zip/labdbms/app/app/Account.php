<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    protected $table = "Account";

    protected $fillable = [
        'ACC_No' , 'ACC_Name' , 'ACC_Surname' , 'Balance'
    ];
}
