@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                <a href="{{ route('account.create') }}" class="btn btn-success">เปิดบัญชี</a>
                </div>
                <div class="panel-heading">
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ACC_No</th>
                            <th scope="col">ACC_Name</th>
                            <th scope="col">ACC_Surname</th>
                            <th scope="col">Balance</th>
                        </tr>
                    </thead>

                    <?php $i=1; ?>
                    @foreach($account as $row)
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                                <td>{{ $row->ACC_NO }}</td>
                                <td>{{ $row->ACC_Name }}</td>
                                <td>{{ $row->ACC_surname }}</td>
                                <td>{{ $row->Balance }}</td>
                        </tr>
                    </tbody>
                    @endforeach
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
