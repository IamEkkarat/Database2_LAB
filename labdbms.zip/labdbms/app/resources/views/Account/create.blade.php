@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <form method="POST" action="{{ route('account.store') }}">
                    {{ csrf_field() }}
                    <table class="table">
                        <tr>
                            <td><label for="ACC_NO">หมายเลขบัญชี</label></td>
                            <td><input type="text" name="ACC_NO"> </td>
                        </tr>
                        <tr><td><label for="ACC_Name">ชื่อ</label></td>
                            <td><input type="text" name="ACC_Name"> </td>
                        </tr>
                        <tr>
                            <td><label for="ACC_surname">นามสกุล</label></td>
                            <td><input type="text" name="ACC_surname"> </td>
                        </tr>
                        <tr>
                            <td><label for="Balance">จำนวนเงิน</label></td>
                            <td><input type="text" name="Balance"> </td>
                        </tr>
                        <td colspan="2" align="center">
                                <button class="btn btn-success" type="submit">เปิดบัญชี</button>
                            </td>
                    </table>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
